|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  3197 | dhiyaneshdk   |  1865 | http       |  8767 | info     |  4101 | file |   435 |
| panel     |  1317 | daffainfo     |   868 | cloud      |   655 | high     |  2406 | dns  |    25 |
| xss       |  1245 | princechaddha |   806 | file       |   435 | medium   |  2332 |      |       |
| wordpress |  1165 | dwisiswant0   |   805 | dast       |   255 | critical |  1368 |      |       |
| exposure  |  1089 | ritikchaddha  |   617 | workflows  |   202 | low      |   318 |      |       |
| wp-plugin |  1019 | pussycat0x    |   516 | code       |   172 | unknown  |    54 |      |       |
| osint     |   809 | pikpikcu      |   352 | network    |   140 |          |       |      |       |
| tech      |   779 | pdteam        |   304 | javascript |    71 |          |       |      |       |
| lfi       |   770 | ricardomaia   |   249 | ssl        |    38 |          |       |      |       |
| rce       |   754 | pdresearch    |   244 | dns        |    22 |          |       |      |       |
